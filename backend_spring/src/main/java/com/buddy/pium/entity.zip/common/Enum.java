package com.buddy.pium.entity.common;

public class Enum {
    public enum Gender {
        M, F
    }

    public enum MateRequestStatus {
        PENDING,    // 대기
        ACCEPTED,   // 수락
        REJECTED    // 거절
    }

}