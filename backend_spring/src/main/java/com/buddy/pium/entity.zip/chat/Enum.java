package com.buddy.pium.entity.chat;

public class Enum {
    public enum ChatRoomType {
        DIRECT,    // 일반 DM
        SHARE,     // 나눔 게시글 기반 DM
        GROUP      // 다인 채팅방
    }
}